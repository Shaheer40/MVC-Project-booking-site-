﻿let a = document.getElementById('sidebar')
/*let b = document.getElementById('sidebar')*/

let slider = document.querySelectorAll('.card');
let cards = document.getElementsByClassName("card");

var count = 0;
function showsidebar() {
    a.classList.toggle('action');
    count++;
}

function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown if the user clicks outside of it
window.onclick = function (event) {
    if (!event.target.matches('.dropbtn')) {
        var dropdowns = document.getElementsByClassName("dropdown-content");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            }
        }
    }
}