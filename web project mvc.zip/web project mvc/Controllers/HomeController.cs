using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using web_project_mvc.Models;

namespace web_project_mvc.Controllers
{
    public class HomeController : Controller
    {

        List<Hotel> list_of_lahore_hotels = new List<Hotel>();
        List<Hotel> list_of_islamabad_hotels = new List<Hotel>();
        List<Hotel> list_of_karachi_hotels = new List<Hotel>();
        List<Hotel> list_of_dubai_hotels = new List<Hotel>();
        List<Hotel> list_of_jaranwala_hotels = new List<Hotel>();

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult aboutus()
        { 
            return View();
        }

        public IActionResult contactus()
        {
            return View();
        }

        //public HomeController()
        //{
        //}

        public IActionResult lahore()
        {

            list_of_lahore_hotels.Add(new Hotel { Id = 1, Name = "quaid hotel", Description = "A1 hotel", location = "lahore" });
            list_of_lahore_hotels.Add(new Hotel { Id = 2, Name = "haweli hotel", Description = "A1 hotel", location = "lahore" });
            list_of_lahore_hotels.Add(new Hotel { Id = 3, Name = "badshahi hotel", Description = "A1 hotel", location = "lahore" });
            list_of_lahore_hotels.Add(new Hotel { Id = 4, Name = "lahore lahore aae hotel", Description = "A1 hotel", location = "lahore" });
            list_of_lahore_hotels.Add(new Hotel { Id = 5, Name = "lahore mansion hotel", Description = "A1 hotel", location = "lahore" });
            list_of_lahore_hotels.Add(new Hotel { Id = 6, Name = "lahore castle hotel", Description = "A1 hotel", location = "lahore" });
            return View(list_of_lahore_hotels);
        }

        public IActionResult islamabad()
        {
            list_of_islamabad_hotels.Add(new Hotel { Id = 1, Name = "burger hotel", Description = "A1 hotel", location = "islamabad" });
            list_of_islamabad_hotels.Add(new Hotel { Id = 2, Name = "cake hotel", Description = "A1 hotel", location = "islamabad" });
            list_of_islamabad_hotels.Add(new Hotel { Id = 3, Name = "islamabad villa hotel", Description = "A1 hotel", location = "islamabad" });
            list_of_islamabad_hotels.Add(new Hotel { Id = 4, Name = "faisal hotel", Description = "A1 hotel", location = "islamabad" });
            list_of_islamabad_hotels.Add(new Hotel { Id = 5, Name = "islamabad mansion hotel", Description = "A1 hotel", location = "islamabad" });
            list_of_islamabad_hotels.Add(new Hotel { Id = 6, Name = "islamabad castle hotel", Description = "A1 hotel", location = "islamabad" });
            list_of_islamabad_hotels.Add(new Hotel { Id = 7, Name = "islamabad helloworld hotel", Description = "A1 hotel", location = "islamabad" });
            return View(list_of_islamabad_hotels);
        }

        public IActionResult karachi()
        {
            list_of_karachi_hotels.Add(new Hotel { Id = 1, Name = "Pan hotel", Description = "A1 hotel", location = "karachi" });
            list_of_karachi_hotels.Add(new Hotel { Id = 2, Name = "Ustad G hotel", Description = "A1 hotel", location = "karachi" });
            list_of_karachi_hotels.Add(new Hotel { Id = 3, Name = "Mobile nikal villa hotel", Description = "A1 hotel", location = "karachi" });
            list_of_karachi_hotels.Add(new Hotel { Id = 4, Name = "Paise nikal hotel", Description = "A1 hotel", location = "karachi" });
            list_of_karachi_hotels.Add(new Hotel { Id = 5, Name = "karachi mansion hotel", Description = "A1 hotel", location = "karachi" });
            return View(list_of_karachi_hotels);
        }

        public IActionResult dubai()
        {
            list_of_dubai_hotels.Add(new Hotel { Id = 1, Name = "burj khalifa hotel", Description = "A1 hotel", location = "dubai" });
            list_of_dubai_hotels.Add(new Hotel { Id = 2, Name = "dubai villa hotel", Description = "A1 hotel", location = "dubai" });
            list_of_dubai_hotels.Add(new Hotel { Id = 3, Name = "dubai castle hotel", Description = "A1 hotel", location = "dubai" });
            list_of_dubai_hotels.Add(new Hotel { Id = 4, Name = "dubai chal hotel", Description = "A1 hotel", location = "dubai" });
            list_of_dubai_hotels.Add(new Hotel { Id = 5, Name = "dubai luxury hotel", Description = "A1 hotel", location = "dubai" });
            list_of_dubai_hotels.Add(new Hotel { Id = 6, Name = "dubai cottage hotel", Description = "A1 hotel", location = "dubai" });
            list_of_dubai_hotels.Add(new Hotel { Id = 7, Name = "Palm tree hotel", Description = "A1 hotel", location = "dubai" });
            list_of_dubai_hotels.Add(new Hotel { Id = 8, Name = "dubai mansion hotel", Description = "A1 hotel", location = "dubai" });
            return View(list_of_dubai_hotels);
        }

        public IActionResult jaranwala()
        {
            list_of_jaranwala_hotels.Add(new Hotel { Id = 1, Name = "burj khalifa hotel", Description = "A1 hotel", location = "jaranwala" });
            list_of_jaranwala_hotels.Add(new Hotel { Id = 2, Name = "dubai villa hotel", Description = "A1 hotel", location = "jaranwala" });
            list_of_jaranwala_hotels.Add(new Hotel { Id = 3, Name = "dubai castle hotel", Description = "A1 hotel", location = "jaranwala" });
            return View(list_of_jaranwala_hotels);
        }
    }
}
