﻿namespace web_project_mvc.Models
{
    public class Hotel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public string location { get; set; }
    }
}
